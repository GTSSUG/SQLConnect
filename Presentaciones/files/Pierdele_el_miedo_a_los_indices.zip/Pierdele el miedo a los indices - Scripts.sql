/*

>>Pierdele el miedo a los indices<<

Mynor Bolanos
SQL.Connect
December 2019

Guatemala - SQL Server user group
https://www.facebook.com/groups/gtssug/


Based in Brant Ozar course: How to Think Like the SQL Server Engine
https://www.brentozar.com/training/think-like-sql-server-engine/

*/
 
 
 
/* 
Configuracion Inicial 


USE [master]
GO

--Habilita opciones avanzadas

EXEC sp_configure 'show advanced option', '1'; 
RECONFIGURE;

--Compatibility Level SQL Server 2019

ALTER DATABASE [StackOverflow2010] SET COMPATIBILITY_LEVEL = 150
GO

--Configura Paralelismo

EXEC sys.sp_configure N'cost threshold for parallelism', N'5'
GO
EXEC sys.sp_configure N'max degree of parallelism', N'0'
GO
RECONFIGURE
GO


--Deshabilita opciones avanzadas
EXEC sp_configure 'show advanced option', '0';
RECONFIGURE;

*/

--Habilita estadisticas de IO

SET STATISTICS IO ON;
GO

--Primer Query

SELECT Id
FROM dbo.Users;
GO
 
--Agreguemos un filtro
SELECT Id
FROM dbo.Users
WHERE LastAccessDate > '2014/07/01';
GO
 

--Agreguemos un ORDER BY
SELECT Id
FROM dbo.Users
WHERE LastAccessDate > '2014/07/01'
ORDER BY LastAccessDate;
GO
 
--Agreguemos todos los campos
SELECT *
FROM dbo.Users
WHERE LastAccessDate > '2014/07/01'
ORDER BY LastAccessDate;
GO
 
--Crea el Nonclusteded Index

IF EXISTS(SELECT 1 FROM sys.indexes WHERE object_id = object_id('dbo.Users') AND NAME ='IX_LastAccessDate_Id')

    CREATE INDEX IX_LastAccessDate_Id ON dbo.Users(LastAccessDate, Id) WITH DROP_EXISTING

ELSE
	
	CREATE INDEX IX_LastAccessDate_Id ON dbo.Users(LastAccessDate, Id) 

--Primer Query

SELECT Id
FROM dbo.Users
WHERE LastAccessDate > '2014/07/01'
ORDER BY LastAccessDate;

--Habilita Estadisticas de CPU

SET STATISTICS TIME, IO ON;

--Comparacion indice vs no indice

SELECT Id
FROM dbo.Users WITH (INDEX = 1) --< forza usar un indice especifico (en este caso obliga a usar un full scan)  
WHERE LastAccessDate > '2014/07/01'
ORDER BY LastAccessDate;
 
SELECT Id
FROM dbo.Users --< SQL selecciona el mejor indice disponible
WHERE LastAccessDate > '2014/07/01'
ORDER BY LastAccessDate;
GO

--<< KEY LOOKUPS >>

--Agreguemos un par de columnas

SELECT Id, DisplayName, Age
FROM dbo.Users
WHERE LastAccessDate > '2014/07/01'
ORDER BY LastAccessDate

--Escenario Comun (SQL Server comunmente ignorara estos indices)

CREATE INDEX IX_Id				ON dbo.Users(Id);
CREATE INDEX IX_DisplayName		ON dbo.Users(DisplayName);
CREATE INDEX IX_Age				ON dbo.Users(Age);
CREATE INDEX IX_CreationDate	ON dbo.Users(CreationDate);
CREATE INDEX IX_Reputation		ON dbo.Users(Reputation);
CREATE INDEX IX_UpVotes			ON dbo.Users(UpVotes);


--<< DEMO >>

--Crea un indice con INCLUDED COLUMNS 
--Las columnas incluidas no afectan el orden del indice y minimizan los LOOKUPS


IF EXISTS(SELECT 1 FROM sys.indexes WHERE object_id = object_id('dbo.Users') AND NAME ='IX_LastAccessDate_Id_DisplayName_Age')

    CREATE INDEX IX_LastAccessDate_Id_DisplayName_Age ON dbo.Users(LastAccessDate, Id) INCLUDE (DisplayName, Age) WITH DROP_EXISTING

ELSE
	
	CREATE INDEX IX_LastAccessDate_Id_DisplayName_Age ON dbo.Users(LastAccessDate, Id) INCLUDE (DisplayName, Age)
